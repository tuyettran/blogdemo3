$(document).ready(function(){
  CKEDITOR.replace('.ckeditor');
});
